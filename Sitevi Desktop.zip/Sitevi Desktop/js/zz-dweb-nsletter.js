/* Newsletter fix */

jQuery(function($){

$('#zone1 > div.block.block-small.quicklinks.side-navigation > ul > li.ql-item.linkid175902 > a').attr("onclick","xt_med('C','','::Newsletter_subscription','N')");

});